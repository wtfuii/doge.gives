(function () {

/* Imports */
var Meteor = Package.meteor.Meteor;



/* Exports */
if (typeof Package === 'undefined') Package = {};
Package['reywood:iron-router-ga'] = {};

})();

//# sourceMappingURL=reywood_iron-router-ga.js.map
